import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UmsModuleRoutingModule } from './ums-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    UmsModuleRoutingModule
  ]
})
export class UmsModule { }
